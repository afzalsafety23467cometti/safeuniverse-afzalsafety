SAFE UNIVERSE HSE — FREE HOSTING PACKAGE
By Afzal — Safety Officer

FILES:
- index.html  = website
- robots.txt  = search engine instructions
- sitemap.xml = Google sitemap template

FREE HOSTING:
GitHub Pages is a simple free option for this static website.
1. Create/sign in to GitHub.
2. Create a new public repository.
3. Upload index.html, robots.txt and sitemap.xml.
4. Enable Settings > Pages > Deploy from branch > main > /(root).
5. GitHub will provide a free *.github.io URL.
6. Replace YOUR-USERNAME and YOUR-REPOSITORY in robots.txt and sitemap.xml with the real URL.
7. Submit that sitemap URL in Google Search Console.

SECURITY:
The current admin login is a browser-only demo and is NOT secure for production.
Do not use the demo password for a real public admin system. A real secure admin needs server-side authentication/database.
